var kapac = document.getElementById("kapacitas");
var kapacSelect = document.getElementById("kapacSelect");
var atvseb = document.getElementById("atvseb");
var atvSelect = document.getElementById("atvSelect");
var akt = document.getElementById("akt");
var gomb = document.getElementById("szamol");
var eredmeny = document.getElementById("eredmeny");

atvseb.addEventListener("mousemove", () => {akt.innerHTML = atvseb.value});
gomb.addEventListener("click", () => {
    let kap = parseFloat(kapac.value);
    let kapSel = parseInt(kapacSelect.value);
    let csuszka = parseInt(atvseb.value);
    let csuszkaSel = parseInt(atvSelect.value);

    switch (kapSel) {
        case 1:
            kap *= 1000;
            break;

        case 2:
            kap *= 1000000;
            break;
    
        default:
            break;
    }

    switch (csuszkaSel) {
        case 0:
            csuszka /= 8;
            break;
        case 1:
            csuszka /= 1000;
            break;
        case 3:
            csuszka *= 1000;
            break;
    
        default:
            break;
    }

    let kivonando = Math.round(kap/csuszka/60)*60;

    eredmeny.innerHTML = (kap/csuszka).toFixed(2) + " sec";
});